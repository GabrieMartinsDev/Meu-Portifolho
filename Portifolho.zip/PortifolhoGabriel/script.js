document.addEventListener("DOMContentLoaded", function () {
    const carousel = document.getElementById("carousel-projetos");
    const slides = carousel.querySelectorAll("[data-carousel-item]");
  
    let currentIndex = 0;
  
    function showSlide(index) {
      slides.forEach((slide, i) => {
        slide.classList.toggle("hidden", i !== index);
      });
    }
  
    // Inicia mostrando o primeiro slide
    showSlide(currentIndex);
  
    // Auto slide a cada 10 segundos
    setInterval(() => {
      currentIndex = (currentIndex + 1) % slides.length;
      showSlide(currentIndex);
    }, 10000);
  });
 
  document.addEventListener("DOMContentLoaded", function () {
    const menuButton = document.getElementById("menu-toggle");
    const mobileMenu = document.getElementById("mobile-menu");

    if (menuButton && mobileMenu) {
      menuButton.addEventListener("click", function () {
        mobileMenu.classList.toggle("hidden"); // Alterna a classe 'hidden'
      });
    }
  });


